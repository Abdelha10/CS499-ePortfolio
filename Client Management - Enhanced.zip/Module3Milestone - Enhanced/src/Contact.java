public class Contact {

	private final String contactID;
	private String firstName;
	private String lastName;
	private String phoneNumber;
	private String address;

	// Constructor
	public Contact(String contactID, String firstName, String lastName, String phoneNumber, String address) {
		this.contactID = contactID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNumber = phoneNumber;
		this.address = address;
		validateAll();
	}

	// Create getter methods
	public String getID() {
		return contactID;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public String getAddress() {
		return address;
	}

	// Create setter methods
	public void setFirstName(String firstName) {
		validateFirstName(firstName);
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		validateLastName(lastName);
		this.lastName = lastName;
	}

	public void setPhoneNumber(String phoneNumber) {
		validatePhoneNumber(phoneNumber);
		this.phoneNumber = phoneNumber;
	}

	public void setAddress(String address) {
		validateAddress(address);
		this.address = address;
	}

	// Helper to validate all contact information
	private void validateAll() {
		validateContactID(contactID);
		validateFirstName(firstName);
		validateLastName(lastName);
		validatePhoneNumber(phoneNumber);
		validateAddress(address);
	}

	// Validation Helpers

	private void validateString(String value, int maxLength, String fieldName) {
		if (value == null || value.length() > maxLength) {
			throw new IllegalArgumentException(
					fieldName + " cannot be null and must be at most " + maxLength + " characters.");
		}
	}

	private void validateContactID(String contactID) {
		validateString(contactID, 10, "Contact ID");
	}

	private void validateFirstName(String firstName) {
		validateString(firstName, 10, "First Name");
	}

	private void validateLastName(String lastName) {
		validateString(lastName, 10, "Last Name");
	}

	private void validatePhoneNumber(String phoneNumber) {
		if (phoneNumber == null || phoneNumber.length() != 10 || !phoneNumber.matches("\\d+")) {
			throw new IllegalArgumentException("Phone Number must be exactly 10 digits.");
		}
	}

	private void validateAddress(String address) {
		validateString(address, 30, "Address");
	}

	@Override
	public String toString() {
		return "Contact{" +
				"contactID='" + contactID + '\'' +
				", firstName='" + firstName + '\'' +
				", lastName='" + lastName + '\'' +
				", phoneNumber='" + phoneNumber + '\'' +
				", address='" + address + '\'' +
				'}';
	}
}
