
import java.util.HashMap;
import java.util.Map;

public class ContactService {
	
	// Create a map to be able to add, delete, and update contacts information with unique ID
	private Map<String, Contact> map;
	
	public ContactService() {
		// Add map elements(contacts)
		map = new HashMap<>();	
	}
	
	// Add contacts
	public void addContacts(Contact contact) {
		
		if (map.containsKey(contact.getID())) {
			 throw new IllegalArgumentException("Contact ID must be unique: " + contact.getID());
		}
		
		map.put(contact.getID(), contact);
		System.out.println("Contact added successfully");
	}
	
	// Remove contacts
	public void removeContact(String contactID) {
		if (this.map.remove(contactID) != null) {
			    System.out.println("Contact deleted successfully: " + contactID);
		} else {
			    System.out.println("Contact with ID " + contactID + " not found");
		}
	}
	
	// Update first name
	public boolean updateFirstName(String contactID, String changeFirstName) {
		if(contactID == null || changeFirstName == null) {
			throw new IllegalArgumentException("Invalid contact ID or first name");
		}
		
		Contact contact = map.get(contactID);
		if (contact == null) {
		    System.out.println("Contact with ID " + contactID + " not found");
		    return false;
		}
		  
		contact.setFirstName(changeFirstName);
		map.put(contactID, contact);
		System.out.println("Contact first name updated successfully");
		return true;
	}
	
	// Update last name
	public boolean updateLastName(String contactID, String changeLastName) {
		if(contactID == null || changeLastName == null) {
				throw new IllegalArgumentException("Invalid contact ID or last name");
		}
			
		Contact contact = map.get(contactID);
		if (contact == null) {
			System.out.println("Contact with ID " + contactID + " not found");
			return false;
		}
			  
		contact.setLastName(changeLastName);
		map.put(contactID, contact);
		System.out.println("Contact last name updated successfully");
		return true;
	}	
	
	// Update address
	public boolean updateAddress(String contactID, String newAddress) {
		if(contactID == null || newAddress == null) {
			throw new IllegalArgumentException("Invalid contact ID or Address");
		}
					
		Contact contact = map.get(contactID);
		if (contact == null) {
			System.out.println("Contact with ID " + contactID + " not found");
			return false;
		}
					  
		contact.setAddress(newAddress);
		map.put(contactID, contact);
		System.out.println("Contact address updated successfully");
		return true;
	}	
	
	// Update phone number
	public boolean updatePhoneNumber(String contactID, String newPhoneNumber) {
		if(contactID == null || newPhoneNumber == null) {
				throw new IllegalArgumentException("Invalid contact ID or phone number");
		}
				
		Contact contact = map.get(contactID);
		if (contact == null) {
			System.out.println("Contact with ID " + contactID + " not found");
			return false;
		}
				  
		contact.setPhoneNumber(newPhoneNumber);
		map.put(contactID, contact);
		System.out.println("Contact phone number updated successfully");
		return true;
	}
	
	public Contact getContact(String taskID)
	{
		return map.get(taskID);
	}
	
	public int getSize() {
		return map.size();
	}
}
