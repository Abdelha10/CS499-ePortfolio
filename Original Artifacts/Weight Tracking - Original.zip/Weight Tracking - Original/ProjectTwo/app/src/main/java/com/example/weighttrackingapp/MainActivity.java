package com.example.weighttrackingapp;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.weighttrackingapp.activities.DataActivity;
import com.example.weighttrackingapp.activities.LoginActivity;
import com.example.weighttrackingapp.adapters.WeightAdapter;
import com.example.weighttrackingapp.database.DatabaseHelper;
import com.example.weighttrackingapp.model.WeightEntry;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {


    /*
        private SharedPreferences sharedPrefs;
        private boolean isLoggedIn = false;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            sharedPrefs = getSharedPreferences("AppPrefs", MODE_PRIVATE);
            isLoggedIn = sharedPrefs.getBoolean("isLoggedIn", false);

            setupUI();
            checkLoginStatus();
        }

        private void setupUI() {
            // main app UI setup
            Button btnLogin = findViewById(R.id.btn_login);
            Button btnContinueAsGuest = findViewById(R.id.btn_guest);

            btnLogin.setOnClickListener(v -> {
                startActivity(new Intent(this, LoginActivity.class));
            });

            btnContinueAsGuest.setOnClickListener(v -> {
                proceedAsGuest();
            });

            // Show/hide features based on login status
            updateUIForLoginStatus();
        }

        private void checkLoginStatus() {
            if (isLoggedIn) {
                String username = sharedPrefs.getString("username", "");
                Toast.makeText(this, "Welcome back, " + username, Toast.LENGTH_SHORT).show();
            }
        }

        private void proceedAsGuest() {
            // Set guest mode in preferences
            SharedPreferences.Editor editor = sharedPrefs.edit();
            editor.putBoolean("isGuest", true);
            editor.apply();

            // Launch main functionality
            startActivity(new Intent(this, DataActivity.class));
        }

        private void updateUIForLoginStatus() {
            // Enable/disable features based on login
            Button btnPremiumFeature = findViewById(R.id.btn_premium);
            btnPremiumFeature.setEnabled(isLoggedIn);
        }

        @Override
        protected void onResume() {
            super.onResume();
            // Refresh login status if returning from LoginActivity
            boolean newLoginStatus = sharedPrefs.getBoolean("isLoggedIn", false);
            if (newLoginStatus != isLoggedIn) {
                isLoggedIn = newLoginStatus;
                updateUIForLoginStatus();
            }
        }


     */


        private static final int LOGIN_REQUEST_CODE = 100;
        private SharedPreferences sharedPrefs;
        private boolean isLoggedIn = false;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            sharedPrefs = getSharedPreferences("AppPrefs", MODE_PRIVATE);
            checkLoginAndRedirect();
            setupUI();
        }

        private void checkLoginAndRedirect() {
            isLoggedIn = sharedPrefs.getBoolean("isLoggedIn", false);

            // If user is already logged in, skip to DataActivity
            if (isLoggedIn) {
                long userId = sharedPrefs.getLong("userId", -1);
                if (userId != -1) {
                    proceedToDataActivity(userId);
                }
            }
        }

        private void setupUI() {
            Button btnLogin = findViewById(R.id.btn_login);
            Button btnGuest = findViewById(R.id.btn_guest);
            Button btnPremium = findViewById(R.id.btn_premium);

            // Login button - launches LoginActivity for result
            btnLogin.setOnClickListener(v -> {
                Intent loginIntent = new Intent(this, LoginActivity.class);
                startActivityForResult(loginIntent, LOGIN_REQUEST_CODE);
            });

            // Guest button
            btnGuest.setOnClickListener(v -> proceedAsGuest());

            // Premium features (only enabled when logged in)
            btnPremium.setEnabled(isLoggedIn);
            btnPremium.setOnClickListener(v -> {
                if (isLoggedIn) {
                    showPremiumFeatures();
                }
            });
        }

        @Override
        protected void onActivityResult(int requestCode, int resultCode, Intent data) {
            super.onActivityResult(requestCode, resultCode, data);

            if (requestCode == LOGIN_REQUEST_CODE) {
                if (resultCode == RESULT_OK) {
                    // Update login status from shared preferences
                    isLoggedIn = sharedPrefs.getBoolean("isLoggedIn", false);
                    updateUIForLoginStatus();

                    if (isLoggedIn) {
                        long userId = sharedPrefs.getLong("userId", -1);
                        if (userId != -1) {
                            proceedToDataActivity(userId);
                        }
                    }
                }
            }
        }

        private void proceedAsGuest() {
            SharedPreferences.Editor editor = sharedPrefs.edit();
            editor.putBoolean("isGuest", true);
            editor.apply();

            // Pass -1 as userId for guest mode
            proceedToDataActivity(-1);
        }

        private void proceedToDataActivity(long userId) {
            Intent intent = new Intent(this, DataActivity.class);
            intent.putExtra("USER_ID", userId);
            startActivity(intent);
            //finish(); // Prevent going back to MainActivity
        }

        private void showPremiumFeatures() {
            Toast.makeText(this, "Premium features unlocked!", Toast.LENGTH_SHORT).show();
            // TODO::premium features here
        }

        private void updateUIForLoginStatus() {
            Button btnPremium = findViewById(R.id.btn_premium);
            btnPremium.setEnabled(isLoggedIn);

            if (isLoggedIn) {
                String username = sharedPrefs.getString("username", "");
                Toast.makeText(this, "Welcome back, " + username, Toast.LENGTH_SHORT).show();
            }
        }

        @Override
        protected void onResume() {
            super.onResume();
            // Refresh UI in case login status changed
            isLoggedIn = sharedPrefs.getBoolean("isLoggedIn", false);
            updateUIForLoginStatus();
        }

    }

