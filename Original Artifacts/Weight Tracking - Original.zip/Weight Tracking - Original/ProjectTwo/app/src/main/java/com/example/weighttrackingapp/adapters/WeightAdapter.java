package com.example.weighttrackingapp.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.weighttrackingapp.R;
import com.example.weighttrackingapp.model.WeightEntry;
import java.util.List;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.WeightViewHolder> {

    private List<WeightEntry> weightEntries;
    private final OnEntryClickListener listener;

    public interface OnEntryClickListener {
        void onDeleteClick(int entryId);
    }

    public WeightAdapter(List<WeightEntry> weightEntries, OnEntryClickListener listener) {
        this.weightEntries = weightEntries;
        this.listener = listener;
    }

    @NonNull
    @Override
    public WeightViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.activity_data_row, parent, false);
        return new WeightViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WeightViewHolder holder, int position) {
        WeightEntry entry = weightEntries.get(position);
        holder.bind(entry, listener);
    }

    @Override
    public int getItemCount() {
        return weightEntries.size();
    }

    public void updateData(List<WeightEntry> newEntries) {
        this.weightEntries = newEntries;
        notifyDataSetChanged();
    }

    static class WeightViewHolder extends RecyclerView.ViewHolder {
        private final TextView nameTextView;
        private final TextView dateTextView;
        private final TextView valueTextView;
        private final View deleteButton;

        public WeightViewHolder(@NonNull View itemView) {
            super(itemView);
            nameTextView = itemView.findViewById(R.id.nameText);
            dateTextView = itemView.findViewById(R.id.dateText);
            valueTextView = itemView.findViewById(R.id.valueText);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }

        public void bind(WeightEntry entry, OnEntryClickListener listener) {
            nameTextView.setText(entry.getName());
            dateTextView.setText(entry.getDate());
            valueTextView.setText(String.valueOf(entry.getValue()));

            deleteButton.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onDeleteClick(entry.getId());
                }
            });
        }
    }
}
