package com.example.weighttrackingapp.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.weighttrackingapp.R;
import com.example.weighttrackingapp.adapters.WeightAdapter;
import com.example.weighttrackingapp.database.DatabaseHelper;
import com.example.weighttrackingapp.model.WeightEntry;
import com.google.android.material.card.MaterialCardView;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class DataActivity extends AppCompatActivity {
    private DatabaseHelper databaseHelper;
    private long currentUserId;
    private RecyclerView recyclerView;
    private WeightAdapter adapter;
    private MaterialCardView addDataCard;
    private EditText nameInput, valueInput;
    private DatePicker datePicker;
    private Button addButton, saveButton, cancelButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_grid); // Your XML layout name

        databaseHelper = new DatabaseHelper(this);
        currentUserId = getIntent().getLongExtra("USER_ID", -1);

        initializeViews();
        setupRecyclerView();
        setupClickListeners();
    }

    private void initializeViews() {
        recyclerView = findViewById(R.id.dataRecyclerView);
        addDataCard = findViewById(R.id.addDataCard);
        nameInput = findViewById(R.id.nameInput);
        valueInput = findViewById(R.id.valueInput);
        datePicker = findViewById(R.id.datePicker);
        addButton = findViewById(R.id.addButton);
        saveButton = findViewById(R.id.saveButton);
        cancelButton = findViewById(R.id.cancelButton);
    }

    private void setupRecyclerView() {
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new WeightAdapter(new ArrayList<>(), this::deleteEntry);
        recyclerView.setAdapter(adapter);
        refreshData();
    }

    private void setupClickListeners() {
        addButton.setOnClickListener(v -> {
            addDataCard.setVisibility(View.VISIBLE);
            // Set default date to today
            Calendar calendar = Calendar.getInstance();
            datePicker.updateDate(calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH));
        });

        saveButton.setOnClickListener(v -> saveEntry());
        cancelButton.setOnClickListener(v -> addDataCard.setVisibility(View.GONE));
    }

    private void saveEntry() {
        String name = nameInput.getText().toString().trim();
        String valueStr = valueInput.getText().toString().trim();

        if (name.isEmpty() || valueStr.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            double value = Double.parseDouble(valueStr);
            // Format date from DatePicker
            String date = String.format(Locale.getDefault(), "%04d-%02d-%02d",
                    datePicker.getYear(), datePicker.getMonth() + 1, datePicker.getDayOfMonth());

            if (databaseHelper.addWeightEntry(currentUserId, name, date, value)) {
                Toast.makeText(this, "Entry saved", Toast.LENGTH_SHORT).show();
                addDataCard.setVisibility(View.GONE);
                nameInput.setText("");
                valueInput.setText("");
                refreshData();
            } else {
                Toast.makeText(this, "Failed to save entry", Toast.LENGTH_SHORT).show();
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid value format", Toast.LENGTH_SHORT).show();
        }
    }

    private void refreshData() {
        List<WeightEntry> entries = databaseHelper.getAllWeightEntries(currentUserId);
        adapter.updateData(entries);
    }

    private void deleteEntry(int entryId) {
        if (databaseHelper.deleteWeightEntry(entryId)) {
            Toast.makeText(this, "Entry deleted", Toast.LENGTH_SHORT).show();
            refreshData();
        } else {
            Toast.makeText(this, "Failed to delete entry", Toast.LENGTH_SHORT).show();
        }
    }
}
