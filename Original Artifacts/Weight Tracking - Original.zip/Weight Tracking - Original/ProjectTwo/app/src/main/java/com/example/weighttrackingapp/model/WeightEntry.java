package com.example.weighttrackingapp.model;

public class WeightEntry {
    private int id;
    private String name;
    private String date;
    private double value;

    public WeightEntry(int id, String name, String date, double value) {
        this.id = id;
        this.name = name;
        this.date = date;
        this.value = value;
    }

    public WeightEntry(int id, String date) {
    }

    // Getters
    public int getId() { return id; }
    public String getName() { return name; }
    public String getDate() { return date; }
    public double getValue() { return value; }

    // Setters if needed
    public void setName(String name) { this.name = name; }
    public void setDate(String date) { this.date = date; }
    public void setValue(double value) { this.value = value; }
}
