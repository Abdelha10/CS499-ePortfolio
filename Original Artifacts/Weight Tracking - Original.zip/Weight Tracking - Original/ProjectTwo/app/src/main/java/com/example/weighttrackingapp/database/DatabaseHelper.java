package com.example.weighttrackingapp.database;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.weighttrackingapp.model.WeightEntry;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "HealthTracker.db";
    private static final int DATABASE_VERSION = 1;

    // Users table
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_USER_ID = "user_id";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";

    // Weight entries table
    private static final String TABLE_WEIGHT_ENTRIES = "weight_entries";
    private static final String COLUMN_ENTRY_ID = "entry_id";
    private static final String COLUMN_ENTRY_NAME = "name";
    private static final String COLUMN_ENTRY_DATE = "date";
    private static final String COLUMN_ENTRY_VALUE = "value";
    private static final String COLUMN_ENTRY_USER_ID = "user_id";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Add constant for guest user ID
    public static final long GUEST_USER_ID = -1;

    public List<WeightEntry> getWeightEntries(long userId) {
        // Modify query to work with guest user
        if (userId == GUEST_USER_ID) {
            // Return sample data or empty list for guests
            return getSampleData();
        }
        // Normal query for logged-in users
        // ...
        return java.util.Collections.emptyList();
    }

    private List<WeightEntry> getSampleData() {
        List<WeightEntry> sampleData = new ArrayList<>();
        sampleData.add(new WeightEntry(70, "2023-05-01"));
        sampleData.add(new WeightEntry(71, "2023-05-08"));
        return sampleData;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create users table
        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + "("
                + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_USERNAME + " TEXT UNIQUE,"
                + COLUMN_PASSWORD + " TEXT" + ")";
        db.execSQL(CREATE_USERS_TABLE);

        // Create weight entries table
        String CREATE_WEIGHT_TABLE = "CREATE TABLE " + TABLE_WEIGHT_ENTRIES + "("
                + COLUMN_ENTRY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_ENTRY_NAME + " TEXT,"
                + COLUMN_ENTRY_DATE + " TEXT,"
                + COLUMN_ENTRY_VALUE + " REAL,"
                + COLUMN_ENTRY_USER_ID + " INTEGER,"
                + "FOREIGN KEY(" + COLUMN_ENTRY_USER_ID + ") REFERENCES "
                + TABLE_USERS + "(" + COLUMN_USER_ID + ")" + ")";
        db.execSQL(CREATE_WEIGHT_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHT_ENTRIES);
        onCreate(db);
    }

    // User management methods
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_USER_ID};
        String selection = COLUMN_USERNAME + " = ?" + " AND " + COLUMN_PASSWORD + " = ?";
        String[] selectionArgs = {username, password};

        Cursor cursor = db.query(TABLE_USERS, columns, selection, selectionArgs,
                null, null, null);
        int count = cursor.getCount();
        cursor.close();
        return count > 0;
    }

    public long getUserId(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_USER_ID};
        String selection = COLUMN_USERNAME + " = ?";
        String[] selectionArgs = {username};

        Cursor cursor = db.query(TABLE_USERS, columns, selection, selectionArgs,
                null, null, null);
        if (cursor.moveToFirst()) {
            @SuppressLint("Range") long id = cursor.getLong(cursor.getColumnIndex(COLUMN_USER_ID));
            cursor.close();
            return id;
        }
        cursor.close();
        return -1;
    }

    // Weight entry methods
    public boolean addWeightEntry(long userId, String name, String date, double value) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ENTRY_NAME, name);
        values.put(COLUMN_ENTRY_DATE, date);
        values.put(COLUMN_ENTRY_VALUE, value);
        values.put(COLUMN_ENTRY_USER_ID, userId);

        long result = db.insert(TABLE_WEIGHT_ENTRIES, null, values);
        return result != -1;
    }



    public List<WeightEntry> getAllWeightEntries(long userId) {
        List<WeightEntry> entries = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String[] columns = {COLUMN_ENTRY_ID, COLUMN_ENTRY_NAME,
                COLUMN_ENTRY_DATE, COLUMN_ENTRY_VALUE};
        String selection = COLUMN_ENTRY_USER_ID + " = ?";
        String[] selectionArgs = {String.valueOf(userId)};

        Cursor cursor = db.query(TABLE_WEIGHT_ENTRIES, columns, selection,
                selectionArgs, null, null, COLUMN_ENTRY_DATE + " DESC");

        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") WeightEntry entry = new WeightEntry(
                        cursor.getInt(cursor.getColumnIndex(COLUMN_ENTRY_ID)),
                        cursor.getString(cursor.getColumnIndex(COLUMN_ENTRY_NAME)),
                        cursor.getString(cursor.getColumnIndex(COLUMN_ENTRY_DATE)),
                        cursor.getDouble(cursor.getColumnIndex(COLUMN_ENTRY_VALUE))
                );
                entries.add(entry);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return entries;
    }

    public boolean deleteWeightEntry(int entryId) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_WEIGHT_ENTRIES, COLUMN_ENTRY_ID + " = ?",
                new String[]{String.valueOf(entryId)}) > 0;
    }
}
