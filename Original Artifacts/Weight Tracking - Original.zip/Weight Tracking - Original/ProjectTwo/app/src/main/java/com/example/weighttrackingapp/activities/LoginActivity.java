package com.example.weighttrackingapp.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.weighttrackingapp.R;
import com.example.weighttrackingapp.database.DatabaseHelper;
import com.google.android.material.textfield.TextInputEditText;


import java.util.Objects;

public class LoginActivity extends AppCompatActivity {


    private TextInputEditText usernameEditText, passwordEditText;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        Button loginButton;
        loginButton = findViewById(R.id.loginButton);
        Button createAccountButton;
        createAccountButton = findViewById(R.id.createAccountButton);

        databaseHelper = new DatabaseHelper(this);

        loginButton.setOnClickListener(v -> loginUser());
        createAccountButton.setOnClickListener(v -> registerUser());
    }

    private void loginUser() {
        String username = Objects.requireNonNull(usernameEditText.getText()).toString().trim();
        String password = Objects.requireNonNull(passwordEditText.getText()).toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        if (databaseHelper.checkUser(username, password)) {
            long userId = databaseHelper.getUserId(username);

            getSharedPreferences("AppPrefs", MODE_PRIVATE)
                    .edit()
                    .putBoolean("isLoggedIn", true)
                    .putString("username", username)
                    .putLong("userId", userId)
                    .apply();

            Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, com.example.weighttrackingapp.activities.DataActivity.class);
            intent.putExtra("USER_ID", userId);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this, "Invalid username or password.", Toast.LENGTH_SHORT).show();
        }
    }

    private void registerUser() {
        String username = Objects.requireNonNull(usernameEditText.getText()).toString().trim();
        String password = Objects.requireNonNull(passwordEditText.getText()).toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean success = databaseHelper.addUser(username, password);
        if (success) {
            Toast.makeText(this, "Account created! You can now log in.", Toast.LENGTH_SHORT).show();
            usernameEditText.setText("");
            passwordEditText.setText("");
        } else {
            Toast.makeText(this, "Username already exists. Try another.", Toast.LENGTH_SHORT).show();
        }
    }

}
