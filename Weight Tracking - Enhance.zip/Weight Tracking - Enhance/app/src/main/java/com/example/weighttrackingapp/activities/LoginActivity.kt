package com.example.weighttrackingapp.activities

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.weighttrackingapp.R
import com.example.weighttrackingapp.database.DatabaseHelper
import com.google.android.material.textfield.TextInputEditText

class LoginActivity : AppCompatActivity() {

    private lateinit var usernameEditText: TextInputEditText
    private lateinit var passwordEditText: TextInputEditText
    private lateinit var databaseHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        usernameEditText = findViewById(R.id.usernameEditText)
        passwordEditText = findViewById(R.id.passwordEditText)
        val loginButton: Button = findViewById(R.id.loginButton)
        val createAccountButton: Button = findViewById(R.id.createAccountButton)

        databaseHelper = DatabaseHelper(this)

        loginButton.setOnClickListener { loginUser() }
        createAccountButton.setOnClickListener { registerUser() }
    }

    private fun loginUser() {
        val username = usernameEditText.text.toString().trim()
        val password = passwordEditText.text.toString().trim()

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter both username and password", Toast.LENGTH_SHORT).show()
            return
        }

        if (databaseHelper.checkUser(username, password)) {
            val userId = databaseHelper.getUserId(username)

            getSharedPreferences("AppPrefs", MODE_PRIVATE)
                .edit()
                .putBoolean("isLoggedIn", true)
                .putString("username", username)
                .putLong("userId", userId)
                .apply()

            Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, DataActivity::class.java)
            intent.putExtra("USER_ID", userId)
            startActivity(intent)
            finish()
        } else {
            Toast.makeText(this, "Invalid username or password.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun registerUser() {
        val username = usernameEditText.text.toString().trim()
        val password = passwordEditText.text.toString().trim()

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter both username and password", Toast.LENGTH_SHORT).show()
            return
        }

        val success = databaseHelper.addUser(username, password)
        if (success) {
            Toast.makeText(this, "Account created! You can now log in.", Toast.LENGTH_SHORT).show()
            usernameEditText.setText("")
            passwordEditText.setText("")
        } else {
            Toast.makeText(this, "Username already exists. Try another.", Toast.LENGTH_SHORT).show()
        }
    }
}
