package com.example.weighttrackingapp.model

data class User(
    var username: String? = null,
    var password: String? = null
)
