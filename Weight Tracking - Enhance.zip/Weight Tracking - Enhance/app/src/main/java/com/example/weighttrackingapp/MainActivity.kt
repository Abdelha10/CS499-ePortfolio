package com.example.weighttrackingapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.weighttrackingapp.activities.DataActivity
import com.example.weighttrackingapp.activities.LoginActivity

/**
 * Main Entry point for the Weight Tracking App.
 *
 * @author Abdel Ouedraogo
 * @version 1.0
 * @since 2025-06-22
 */

class MainActivity : AppCompatActivity() {

    private var isLoggedIn = false
    private val sharedPrefs by lazy { getSharedPreferences("AppPrefs", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        checkLoginAndRedirect()
        setupUI()
    }

    private fun checkLoginAndRedirect() {
        isLoggedIn = sharedPrefs.getBoolean("isLoggedIn", false)

        // If user is already logged in, skip to DataActivity
        if (isLoggedIn) {
            val userId = sharedPrefs.getLong("userId", -1)
            if (userId != -1L) {
                proceedToDataActivity(userId)
            }
        }
    }

    private fun setupUI() {
        val btnLogin: Button = findViewById(R.id.btn_login)
        val btnGuest: Button = findViewById(R.id.btn_guest)
        val btnPremium: Button = findViewById(R.id.btn_premium)

        // Login button - launches LoginActivity for result
        btnLogin.setOnClickListener {
            val loginIntent = Intent(this, LoginActivity::class.java)
            startActivityForResult(loginIntent, LOGIN_REQUEST_CODE)
        }

        // Guest button
        btnGuest.setOnClickListener { proceedAsGuest() }

        // Premium features (only enabled when logged in)
        btnPremium.isEnabled = isLoggedIn
        btnPremium.setOnClickListener {
            if (isLoggedIn) {
                showPremiumFeatures()
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == LOGIN_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                // Update login status from shared preferences
                isLoggedIn = sharedPrefs.getBoolean("isLoggedIn", false)
                updateUIForLoginStatus()

                if (isLoggedIn) {
                    val userId = sharedPrefs.getLong("userId", -1)
                    if (userId != -1L) {
                        proceedToDataActivity(userId)
                    }
                }
            }
        }
    }

    private fun proceedAsGuest() {
        sharedPrefs.edit().putBoolean("isGuest", true).apply()

        // Pass -1 as userId for guest mode
        proceedToDataActivity(-1)
    }

    private fun proceedToDataActivity(userId: Long) {
        val intent = Intent(this, DataActivity::class.java)
        intent.putExtra("USER_ID", userId)
        startActivity(intent)
        //finish(); // Prevent going back to MainActivity
    }

    private fun showPremiumFeatures() {
        Toast.makeText(this, "Premium features unlocked!", Toast.LENGTH_SHORT).show()
        // TODO::implement premium features
    }

    private fun updateUIForLoginStatus() {
        val btnPremium: Button = findViewById(R.id.btn_premium)
        btnPremium.isEnabled = isLoggedIn

        if (isLoggedIn) {
            val username = sharedPrefs.getString("username", "")
            Toast.makeText(this, "Welcome back, $username", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onResume() {
        super.onResume()
        // Refresh UI in case login status changed
        isLoggedIn = sharedPrefs.getBoolean("isLoggedIn", false)
        updateUIForLoginStatus()
    }

    companion object {
        private const val LOGIN_REQUEST_CODE = 100
    }
}
