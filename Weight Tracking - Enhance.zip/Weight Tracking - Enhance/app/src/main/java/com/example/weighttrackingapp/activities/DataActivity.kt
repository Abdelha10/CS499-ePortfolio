package com.example.weighttrackingapp.activities

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.DatePicker
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.weighttrackingapp.R
import com.example.weighttrackingapp.adapters.WeightAdapter
import com.example.weighttrackingapp.database.DatabaseHelper
import com.example.weighttrackingapp.permissions.SmsPermissionActivity
import com.google.android.material.card.MaterialCardView
import java.util.Calendar
import java.util.Locale

class DataActivity : AppCompatActivity() {

    private lateinit var databaseHelper: DatabaseHelper
    private var currentUserId: Long = -1
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: WeightAdapter
    private lateinit var addDataCard: MaterialCardView
    private lateinit var nameInput: EditText
    private lateinit var valueInput: EditText
    private lateinit var datePicker: DatePicker
    private lateinit var addButton: Button
    private lateinit var saveButton: Button
    private lateinit var cancelButton: Button

    private var isGuest: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_data_grid)

        databaseHelper = DatabaseHelper(this)
        currentUserId = intent.getLongExtra("USER_ID", -1)
        isGuest = currentUserId == -1L

        initializeViews()
        setupRecyclerView()
        setupClickListeners()

        // Request SMS permission only for logged-in users
        if (!isGuest) {
            checkSmsPermission()
        }
    }

    private fun initializeViews() {
        recyclerView = findViewById(R.id.dataRecyclerView)
        addDataCard = findViewById(R.id.addDataCard)
        nameInput = findViewById(R.id.nameInput)
        valueInput = findViewById(R.id.valueInput)
        datePicker = findViewById(R.id.datePicker)
        addButton = findViewById(R.id.addButton)
        saveButton = findViewById(R.id.saveButton)
        cancelButton = findViewById(R.id.cancelButton)
    }

    private fun setupRecyclerView() {
        recyclerView.layoutManager = LinearLayoutManager(this)
        // Pass a wrapper implementing OnEntryClickListener or lambda if interface is functional
        adapter = WeightAdapter(ArrayList(), object : WeightAdapter.OnEntryClickListener {
            override fun onDeleteClick(entryId: Int) {
                deleteEntry(entryId)
            }
        })
        recyclerView.adapter = adapter
        refreshData()
    }

    private fun setupClickListeners() {
        addButton.setOnClickListener {
            addDataCard.visibility = View.VISIBLE
            // Set default date to today
            val calendar = Calendar.getInstance()
            datePicker.updateDate(
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
            )
        }

        saveButton.setOnClickListener { saveEntry() }
        cancelButton.setOnClickListener { addDataCard.visibility = View.GONE }
    }

    private fun saveEntry() {
        val name = nameInput.text.toString().trim()
        val valueStr = valueInput.text.toString().trim()

        if (name.isEmpty() || valueStr.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val value = valueStr.toDouble()
            // Format date from DatePicker
            val date = String.format(
                Locale.getDefault(), "%04d-%02d-%02d",
                datePicker.year, datePicker.month + 1, datePicker.dayOfMonth
            )

            if (databaseHelper.addWeightEntry(currentUserId, name, date, value)) {
                Toast.makeText(this, "Entry saved", Toast.LENGTH_SHORT).show()
                addDataCard.visibility = View.GONE
                nameInput.setText("")
                valueInput.setText("")
                refreshData()
            } else {
                Toast.makeText(this, "Failed to save entry", Toast.LENGTH_SHORT).show()
            }
        } catch (e: NumberFormatException) {
            Toast.makeText(this, "Invalid value format", Toast.LENGTH_SHORT).show()
        }
    }

    private fun refreshData() {
        val entries = databaseHelper.getAllWeightEntries(currentUserId)
        adapter.updateData(entries)
    }

    private fun deleteEntry(entryId: Int) {
        if (databaseHelper.deleteWeightEntry(entryId)) {
            Toast.makeText(this, "Entry deleted", Toast.LENGTH_SHORT).show()
            refreshData()
        } else {
            Toast.makeText(this, "Failed to delete entry", Toast.LENGTH_SHORT).show()
        }
    }

    // SMS permission helper Methods
    private fun checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
            != PackageManager.PERMISSION_GRANTED) {

            // Show explanation first if needed
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)) {
                showSmsRationale()
            } else {
                launchSmsPermissionActivity()
            }
        }
    }

    private fun showSmsRationale() {
        AlertDialog.Builder(this)
            .setTitle("SMS Notifications")
            .setMessage("To send weight reminder alerts, we need SMS permissions")
            .setPositiveButton("Continue") { _, _ -> launchSmsPermissionActivity() }
            .setNegativeButton("Not Now", null)
            .show()
    }

    private fun launchSmsPermissionActivity() {
        val intent = Intent(this, SmsPermissionActivity::class.java)
        startActivityForResult(intent, SMS_PERMISSION_REQUEST)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == SMS_PERMISSION_REQUEST) {
            if (resultCode == RESULT_OK) {
                Toast.makeText(this, "SMS features enabled", Toast.LENGTH_SHORT).show()
            }
        }
    }

    companion object {
        private const val SMS_PERMISSION_REQUEST = 100
    }
}
