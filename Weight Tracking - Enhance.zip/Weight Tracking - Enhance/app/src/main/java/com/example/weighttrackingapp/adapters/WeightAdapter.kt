package com.example.weighttrackingapp.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.weighttrackingapp.R
import com.example.weighttrackingapp.model.WeightEntry

class WeightAdapter(
    private var weightEntries: List<WeightEntry>,
    private val listener: OnEntryClickListener
) : RecyclerView.Adapter<WeightAdapter.WeightViewHolder>() {

    interface OnEntryClickListener {
        fun onDeleteClick(entryId: Int)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WeightViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.activity_data_row, parent, false)
        return WeightViewHolder(view)
    }

    override fun onBindViewHolder(holder: WeightViewHolder, position: Int) {
        val entry = weightEntries[position]
        holder.bind(entry, listener)
    }

    override fun getItemCount(): Int {
        return weightEntries.size
    }

    fun updateData(newEntries: List<WeightEntry>) {
        this.weightEntries = newEntries
        notifyDataSetChanged()
    }

    class WeightViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val nameTextView: TextView = itemView.findViewById(R.id.nameText)
        private val dateTextView: TextView = itemView.findViewById(R.id.dateText)
        private val valueTextView: TextView = itemView.findViewById(R.id.valueText)
        private val deleteButton: View = itemView.findViewById(R.id.deleteButton)

        fun bind(entry: WeightEntry, listener: OnEntryClickListener?) {
            nameTextView.text = entry.name
            dateTextView.text = entry.date
            valueTextView.text = entry.value.toString()

            deleteButton.setOnClickListener {
                listener?.onDeleteClick(entry.id)
            }
        }
    }
}
