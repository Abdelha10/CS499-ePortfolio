package com.example.weighttrackingapp.model

data class WeightEntry(
    var id: Int = 0,
    var name: String? = null,
    var date: String? = null,
    var value: Double = 0.0
) {
    constructor(id: Int, date: String?) : this(id, null, date, 0.0)

}
