package com.example.weighttrackingapp.permissions

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.weighttrackingapp.R

class SmsPermissionActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sms_permission)

        val grantButton: Button = findViewById(R.id.btn_grant_permission)
        val denyButton: Button = findViewById(R.id.btn_deny_permission)

        grantButton.setOnClickListener { checkAndRequestSmsPermission() }

        denyButton.setOnClickListener {
            setResult(RESULT_CANCELED)
            finish()
        }
    }

    private fun checkAndRequestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
            != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.SEND_SMS),
                SMS_PERMISSION_REQUEST_CODE
            )
        } else {
            sendSmsMessage() // Already has permission
        }
    }

    private fun sendSmsMessage() {
        // TODO:: implement SMS logic here
        Toast.makeText(this, "SMS Permission Granted. Ready to send messages.", Toast.LENGTH_SHORT).show()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                setResult(RESULT_OK)
            } else {
                setResult(RESULT_CANCELED)
            }
            finish()
        }
    }

    companion object {
        private const val SMS_PERMISSION_REQUEST_CODE = 100
    }
}
