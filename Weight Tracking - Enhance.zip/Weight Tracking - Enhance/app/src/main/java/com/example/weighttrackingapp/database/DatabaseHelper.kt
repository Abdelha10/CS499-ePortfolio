package com.example.weighttrackingapp.database

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.weighttrackingapp.model.WeightEntry
import java.util.ArrayList

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "HealthTracker.db"
        private const val DATABASE_VERSION = 1

        // Users table
        private const val TABLE_USERS = "users"
        private const val COLUMN_USER_ID = "user_id"
        private const val COLUMN_USERNAME = "username"
        private const val COLUMN_PASSWORD = "password"

        // Weight entries table
        private const val TABLE_WEIGHT_ENTRIES = "weight_entries"
        private const val COLUMN_ENTRY_ID = "entry_id"
        private const val COLUMN_ENTRY_NAME = "name"
        private const val COLUMN_ENTRY_DATE = "date"
        private const val COLUMN_ENTRY_VALUE = "value"
        private const val COLUMN_ENTRY_USER_ID = "user_id"
    }

    override fun onCreate(db: SQLiteDatabase) {
        // Create users table
        val createUsersTable = "CREATE TABLE $TABLE_USERS(" +
                "$COLUMN_USER_ID INTEGER PRIMARY KEY AUTOINCREMENT," +
                "$COLUMN_USERNAME TEXT UNIQUE," +
                "$COLUMN_PASSWORD TEXT)"
        db.execSQL(createUsersTable)

        // Create weight entries table
        val createWeightTable = "CREATE TABLE $TABLE_WEIGHT_ENTRIES(" +
                "$COLUMN_ENTRY_ID INTEGER PRIMARY KEY AUTOINCREMENT," +
                "$COLUMN_ENTRY_NAME TEXT," +
                "$COLUMN_ENTRY_DATE TEXT," +
                "$COLUMN_ENTRY_VALUE REAL," +
                "$COLUMN_ENTRY_USER_ID INTEGER," +
                "FOREIGN KEY($COLUMN_ENTRY_USER_ID) REFERENCES $TABLE_USERS($COLUMN_USER_ID))"
        db.execSQL(createWeightTable)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_USERS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_WEIGHT_ENTRIES")
        onCreate(db)
    }

    // User management methods
    fun addUser(username: String, password: String): Boolean {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_USERNAME, username)
            put(COLUMN_PASSWORD, password)
        }

        val result = db.insert(TABLE_USERS, null, values)
        return result != -1L
    }

    fun checkUser(username: String, password: String): Boolean {
        val db = this.readableDatabase
        val columns = arrayOf(COLUMN_USER_ID)
        val selection = "$COLUMN_USERNAME = ? AND $COLUMN_PASSWORD = ?"
        val selectionArgs = arrayOf(username, password)

        val cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null)
        val count = cursor.count
        cursor.close()
        return count > 0
    }

    @SuppressLint("Range")
    fun getUserId(username: String): Long {
        val db = this.readableDatabase
        val columns = arrayOf(COLUMN_USER_ID)
        val selection = "$COLUMN_USERNAME = ?"
        val selectionArgs = arrayOf(username)

        val cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null)
        if (cursor.moveToFirst()) {
            val id = cursor.getLong(cursor.getColumnIndex(COLUMN_USER_ID))
            cursor.close()
            return id
        }
        cursor.close()
        return -1
    }

    // Weight entry methods
    fun addWeightEntry(userId: Long, name: String?, date: String?, value: Double): Boolean {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_ENTRY_NAME, name)
            put(COLUMN_ENTRY_DATE, date)
            put(COLUMN_ENTRY_VALUE, value)
            put(COLUMN_ENTRY_USER_ID, userId)
        }

        val result = db.insert(TABLE_WEIGHT_ENTRIES, null, values)
        return result != -1L
    }

    @SuppressLint("Range")
    fun getAllWeightEntries(userId: Long): List<WeightEntry> {
        val entries = ArrayList<WeightEntry>()
        val db = this.readableDatabase

        val columns = arrayOf(COLUMN_ENTRY_ID, COLUMN_ENTRY_NAME, COLUMN_ENTRY_DATE, COLUMN_ENTRY_VALUE)
        val selection = "$COLUMN_ENTRY_USER_ID = ?"
        val selectionArgs = arrayOf(userId.toString())

        val cursor = db.query(TABLE_WEIGHT_ENTRIES, columns, selection, selectionArgs, null, null, "$COLUMN_ENTRY_DATE DESC")

        if (cursor.moveToFirst()) {
            do {
                val entry = WeightEntry(
                    cursor.getInt(cursor.getColumnIndex(COLUMN_ENTRY_ID)),
                    cursor.getString(cursor.getColumnIndex(COLUMN_ENTRY_NAME)),
                    cursor.getString(cursor.getColumnIndex(COLUMN_ENTRY_DATE)),
                    cursor.getDouble(cursor.getColumnIndex(COLUMN_ENTRY_VALUE))
                )
                entries.add(entry)
            } while (cursor.moveToNext())
        }
        cursor.close()
        return entries
    }

    fun deleteWeightEntry(entryId: Int): Boolean {
        val db = this.writableDatabase
        return db.delete(TABLE_WEIGHT_ENTRIES, "$COLUMN_ENTRY_ID = ?", arrayOf(entryId.toString())) > 0
    }
}
