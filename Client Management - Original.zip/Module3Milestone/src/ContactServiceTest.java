/* author: Abdel Ouedraogo
 * Date: 8/11/2024
 * CS 320
 * Project One
 * program: ContactServiceTess Class
 */

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    private ContactService contactService;

    @BeforeEach
    public void setUp() {
        this.contactService = new ContactService();
    }

    //Checks that the method successfully adds a new contact to the internal map
    @Test
    public void testAddContact() {
    	Contact contact1 = new Contact("0123999991", "Abel", "Daniels", "6669944443", "444 Cornell St");
        this.contactService.addContacts(contact1);
        assertEquals(contact1, contactService.getContact("0123999991"));

        // Trying to add the same appointment again should not overwrite the existing one
        // Trying to add the same appointment again should throw an exception
        try {
            this.contactService.addContacts(contact1);
            fail("Expected IllegalArgumentException for duplicate contact ID");
        } catch (IllegalArgumentException e) {
            assertEquals("Contact ID must be unique: 0123999991", e.getMessage());
        }
        assertEquals(1, contactService.getSize());
    }

    //Checks that the removeContact method successfully removes a contact based on its phone number (key) from the internal map.
    @Test
    public void testRemoveContact() {
        Contact contact1 = new Contact("2894664", "Jon", "Ruth", "1234567890", "442 Rare Plane Rd");
        contactService.addContacts(contact1);
        contactService.removeContact("2894664");
        assertNull(contactService.getContact("2894664"));
        
    }

    
    //Checks that updateFirstName can modify the first name of an existing contact identified by its key
    @Test
    public void testUpdateFirstName() {
        Contact contact1 = new Contact("0123999991", "Abel", "Daniels", "6669944443", "444 Cornell St");
        contactService.addContacts(contact1);
        assertTrue(contactService.updateFirstName("0123999991", "John"));
        assertEquals("John", contactService.getContact("0123999991").getFirstName());
    }

    //Checks that updatelastName can modify the last name of an existing contact identified by its key
    @Test
    public void testUpdateLastName() {
        Contact contact1 = new Contact("0123999991", "Abel", "Daniels", "6669944443", "444 Cornell St");
        contactService.addContacts(contact1);
        assertTrue(contactService.updateLastName("0123999991", "Smith"));
        assertEquals("Smith", contactService.getContact("0123999991").getLastName());
    }

    //Checks that updateAddress can modify the address of an existing contact identified by its key
    @Test
    public void testUpdateAddress() {
        Contact contact1 = new Contact("0123999991", "Abel", "Daniels", "6669944443", "444 Cornell St");
        contactService.addContacts(contact1);
        assertTrue(contactService.updateAddress("0123999991", "123 New St"));
        assertEquals("123 New St", contactService.getContact("0123999991").getAddress());
    }

    //Checks that updatePhoneNumber can modify the phone number of an existing contact identified by its key
    @Test
    public void testUpdatePhoneNumber() {
        Contact contact1 = new Contact("0123999991", "Abel", "Daniels", "6669944443", "444 Cornell St");
        contactService.addContacts(contact1);
        assertTrue(contactService.updatePhoneNumber("0123999991", "5551234567"));
        assertEquals("5551234567", contactService.getContact("0123999991").getPhoneNumber());
    }

    //Checks that the addContacts method doesn't replace an existing contact if a new contact 
    //with the same ID (key) is added
    @Test
    public void testAddDuplicateContact() {
        Contact contact1 = new Contact("0123999991", "Abel", "Daniels", "6669944443", "444 Cornell St");
        contactService.addContacts(contact1);

        // Add a contact with the same ID
        Contact contactDuplicate = new Contact("0123999991", "Jane", "Doe", "5551234567", "555 New St");

        try {
            contactService.addContacts(contactDuplicate);
        } catch (IllegalArgumentException e) {
            // This is expected as the ID is duplicate
            assertEquals("Contact ID must be unique: 0123999991", e.getMessage());
        }

        // Retrieve the appointment by ID
        Contact retrievedContact = contactService.getContact("0123999991");
        // The original contact should not be replaced
        assertEquals("Abel", retrievedContact.getFirstName());
        assertEquals("Daniels", retrievedContact.getLastName());
        assertEquals("6669944443", retrievedContact.getPhoneNumber());
        assertEquals("444 Cornell St", retrievedContact.getAddress());

        
    }

    //Checks that the removeContact method doesn't throw errors when trying to remove a non-existent contact.
    @Test
    public void testRemoveNonExistentContact() {
        contactService.removeContact("nonExistentID");
        assertEquals(0, contactService.getSize());
    }

    //Checks that the update methods return false when trying to update a non-existent contact.
    @Test
    public void testUpdateNonExistentContact() {
        assertFalse(contactService.updateFirstName("nonExistentID", "Rose"));
        assertFalse(contactService.updateLastName("nonExistentID", "John"));
        assertFalse(contactService.updateAddress("nonExistentID", "113 Bad St"));
        assertFalse(contactService.updatePhoneNumber("nonExistentID", "9999991111"));
    }
}