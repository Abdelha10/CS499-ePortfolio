/* author: Abdel Ouedraogo
 * Date: 8/11/2024
 * CS 320
 * Project One
 * program: TaskServiceTest Class
 */

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TaskServiceTest {

	
	private TaskService taskService;

    @BeforeEach
    public void setUp() {
        this.taskService = new TaskService();
    }

    //Checks that the method successfully adds a new task to the internal map
    @Test
    public void testAddContact() {
        Task task1 = new Task("111112345T", "Ugrade", "Upgrade the customers service program");
        this.taskService.addTask(task1);
        assertEquals(task1, taskService.getTask("111112345T"));

        // Trying to add the same task again should not overwrite the existing one
        try {
            this.taskService.addTask(task1);
            fail("Expected IllegalArgumentException for duplicate appointment ID");
        } catch (IllegalArgumentException e) {
            assertEquals("Task ID must be unique: 111112345T", e.getMessage());
        }
        assertEquals(1, taskService.getSize());
    }

    //Checks that the remove task method successfully removes a task based on its key from the internal map.
    @Test
    public void testRemoveTask() {
        Task task2 = new Task("111112346T", "Clean", "Organize the meeting areas");
        taskService.addTask(task2);
        taskService.removeTask("111112346T");
        assertNull(taskService.getTask("111112346T"));
    }

    
    //Checks that updateTaskName can modify the task name of an existing task identified by its key
    @Test
    public void testUpdateTaskName() {
    	Task task2 = new Task("111112346T", "Clean", "Organize the meeting areas");
        taskService.addTask(task2);
        assertTrue(taskService.updateTaskName("111112346T", "Organize"));
        assertEquals("Organize", taskService.getTask("111112346T").getTaskName());
    }

    //Checks that updateTaskDescription can modify the description of an existing task identified by its key
    @Test
    public void testUpdateTaskDescription() {
    	Task task3 = new Task("111112347T", "Customer support", "Respond to customer inquiries");
        taskService.addTask(task3);
        assertTrue(taskService.updateTaskDescription("111112347T", "Resolve issues and providees customers information"));
        assertEquals("Resolve issues and providees customers information", taskService.getTask("111112347T").getTaskDescription());
    }

    //Checks that the addTask method doesn't replace an existing task if a new task 
    //with the same ID (key) is added
    @Test
    public void testAddDuplicateTask() {
        Task task4 = new Task("0123999991", "Process orders", "Process incoming orders");
        taskService.addTask(task4);

        // Add a task with the same ID
        Task taskDuplicate = new Task("0123999991", "Process Email", "Process incoming email");
        try {
            taskService.addTask(taskDuplicate);
        } catch (IllegalArgumentException e) {
            // This is expected as the ID is duplicate
            assertEquals("Task ID must be unique: 0123999991", e.getMessage());
        }

        // The original task should not be replaced
        Task retrievedTask = taskService.getTask("0123999991");
        assertEquals("Process orders", retrievedTask.getTaskName());
        assertEquals("Process incoming orders", retrievedTask.getTaskDescription());
    }

    //Checks that the removeContact method doesn't throw errors when trying to remove a non-existent task.
    @Test
    public void testRemoveNonExistentContact() {
        taskService.removeTask("nonExistentID");
        assertEquals(0, taskService.getSize());
    }

    //Checks that the update methods return false when trying to update a non-existent task.
    @Test
    public void testUpdateNonExistentContact() {
        assertFalse(taskService.updateTaskName("nonExistentID", "Pull"));
        assertFalse(taskService.updateTaskDescription("nonExistentID", "Clean"));
    }
}
