/* author: Abdel Ouedraogo
 * Date: 08/11/2024
 * CS 320
 * Project One
 * program: AppointmentServiceTest Class
 */

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AppointmentServiceTest {

	private AppointmentService apptService;
	
	@BeforeEach
    public void setUp() {
        this.apptService = new AppointmentService();
    }

    //Checks that the method successfully adds a new appointment to the internal map
    @Test
    public void testAddAppointment() {
    	Date initialDate = new Date(System.currentTimeMillis() + 3600 * 1000);
        Appointment appt1 = new Appointment("111112345A",initialDate, "Service program");
        this.apptService.addAppointment(appt1);
        assertEquals(appt1, apptService.getAppointment("111112345A"));

        // Trying to add the same appointment again should not overwrite the existing one
        // Trying to add the same appointment again should throw an exception
        try {
            this.apptService.addAppointment(appt1);
            fail("Expected IllegalArgumentException for duplicate appointment ID");
        } catch (IllegalArgumentException e) {
            assertEquals("Appointment ID must be unique: 111112345A", e.getMessage());
        }
        assertEquals(1, apptService.getSize());
    }
    
    
    //Checks that the remove appointment method successfully removes an appointment based on its key from the internal map.
    @Test
    public void testRemoveAppointment() {
    	Date date = new Date(System.currentTimeMillis() + 3600 * 1000);
        Appointment appt2 = new Appointment("111112346A", date, "Meeting areas");
        apptService.addAppointment(appt2);
        apptService.removeAppointment("111112346A");
        assertNull(apptService.getAppointment("111112346T"));
    }
    
    //Checks that the addAppointment method doesn't replace an existing appointment if a new appointment 
    //with the same ID (key) is added
    @Test
    public void testAddDuplicateAppointment() {
    	// Initialize the AppointmentService
        AppointmentService apptService = new AppointmentService();
        
        // Initial appointment
        Date initialDate = new Date(System.currentTimeMillis() + 3600 * 1000);
        Appointment appt3 = new Appointment("012399999A", initialDate, "Discuss incoming orders");
        apptService.addAppointment(appt3);

        // Attempt to add a duplicate appointment with the same ID but different details
        Date newDate = new Date(System.currentTimeMillis() + 3800 * 1000);
        Appointment apptDuplicate = new Appointment("012399999A", newDate, "Process incoming email");
        try {
            apptService.addAppointment(apptDuplicate);
        } catch (IllegalArgumentException e) {
            // This is expected as the ID is duplicate
            assertEquals("Appointment ID must be unique: 012399999A", e.getMessage());
        }

        // Retrieve the appointment by ID
        Appointment retrievedAppt = apptService.getAppointment("012399999A");

        // The original appointment should not be replaced
        assertEquals(initialDate, retrievedAppt.getAppointmentDate());
        assertEquals("Discuss incoming orders", retrievedAppt.getAppointmentDescription());
    }

    //Checks that the removeAppointment method doesn't throw errors when trying to remove a non-existent appointment.
    @Test
    public void testRemoveNonExistentAppointment() {
        apptService.removeAppointment("nonExistentID");
        assertEquals(0, apptService.getSize());
    }
    
    //Checks that get appointment method works
    @Test
    public void testGetExistingAppointment() {
        AppointmentService apptService = new AppointmentService();
        Date initialDate = new Date(System.currentTimeMillis() + 3600 * 1000);
        Appointment appt1 = new Appointment("111112345A", initialDate, "Service program");

        // Add the appointment to the service
        apptService.addAppointment(appt1);

        // Retrieve the appointment by ID
        Appointment retrievedAppt = apptService.getAppointment("111112345A");

        // Check if the retrieved appointment is the same as the added one
        assertEquals(appt1, retrievedAppt);
    }

    //Check that get appointment send a message when trying to retrieve a non existent appointment
    @Test
    public void testGetNonExistingAppointment() {
        AppointmentService apptService = new AppointmentService();

        // Try to retrieve an appointment with an ID that doesn't exist
        Appointment retrievedAppt = apptService.getAppointment("nonexistentID");

        // Check that the retrieved appointment is null
        assertNull(retrievedAppt);
    }

   
}
