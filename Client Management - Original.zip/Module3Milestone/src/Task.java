
public class Task {

	private final String taskID;
	private String taskName;
	private String taskDescription;
	
	// Constructor to initialize task ID
	public Task(String taskID){
		this.taskID = taskID;
	}
	
	Task(String taskID, String taskName, String taskDescription) {
		//variables initiation
		this.taskID = taskID;
		this.taskName = taskName;
		this.taskDescription = taskDescription;
		validateAll();
	}
	
	
	// Create getter methods
	public String getTaskID() {
		return taskID;
	}
	
	
	public String getTaskName() {
		return taskName;
	}
	
	public String getTaskDescription() {
		return taskDescription;
	}
	
	//Create setter methods
	public void setTaskName(String taskName) {
		Task.validateTaskName(taskName);
		this.taskName = taskName;
	}
	
	public void setTaskDescription(String taskDescription) {
		Task.validateTaskDescription(taskDescription);
		this.taskDescription = taskDescription;
	}
	
	//validate task ID
	private static void validateTaskID(String taskID) {
		if (taskID == null || taskID.length() > 10) {
			throw new IllegalArgumentException("Invalid task ID");
		}
		
	}
		
	// validate task name
	private static void validateTaskName(String taskName) {
		if (taskName == null || taskName.length() > 20) {
			throw new IllegalArgumentException("Invalid task Name");
		}
	}
	
	// validate task description
	private static void validateTaskDescription(String taskDescription) {
		if (taskDescription == null || taskDescription.length() > 50) {
			throw new IllegalArgumentException("Invalid description");
		}
	}
	
	private void validateAll() {
		Task.validateTaskID(taskID);
		Task.validateTaskName(taskName);
		Task.validateTaskDescription(taskDescription);
	}
	
	@Override
    public String toString() {
        return "Task{" +
                "taskID='" + taskID + '\'' +
                ", taskName='" + taskName + '\'' +
                ", taskDescription='" + taskDescription + '\'' +      
                '}';
    }
	
		
}
