import java.text.SimpleDateFormat;
import java.util.Date;

public class Appointment {
	private final String appointmentID;
	private Date appointmentDate;
	private String appointmentDescription;
	
	public Appointment(String appointmentID, Date appointmentDate, String appointmentDescription){
		this.appointmentID = appointmentID;
		this.appointmentDate = appointmentDate;
		this.appointmentDescription = appointmentDescription;
		validateAll();
	}
	
	
	//Create getter methods
	public String getAppointmentID() {
		return this.appointmentID;
	}
	
	public Date getAppointmentDate() {
		return this.appointmentDate;
	}
	
	public String getAppointmentDescription() {
		return this.appointmentDescription;
	}
	
	//Create setter methods
	public void setAppointmentDate(Date appointmentDate) {
		validateAppointmentDate(appointmentDate);
		this.appointmentDate = appointmentDate;
	}
	
	public void setAppointmentDescription(String appointmentDescription) {
		validateAppointmentDescription(appointmentDescription);
		this.appointmentDescription = appointmentDescription;
	}
	
	//validate task ID
	private static void validateAppointmentID(String appointmentID) {
		if (appointmentID == null || appointmentID.length() > 10) {
			throw new IllegalArgumentException("Invalid appointment ID");
		}		
	}
	
	// Validation method for appointment date
    private void validateAppointmentDate(Date appointmentDate) {
        if (appointmentDate == null) {
            throw new IllegalArgumentException("Appointment date cannot be null");
        }
        if (appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Appointment date cannot be in the past");
        }
    }
    
    // validate appointment  description
 	private static void validateAppointmentDescription(String appointmentDescription) {
 		if (appointmentDescription == null || appointmentDescription.length() > 50) {
 			throw new IllegalArgumentException("Invalid description");
 		}
 	}
 	
 	private void validateAll() {
		Appointment.validateAppointmentID(appointmentID);
		validateAppointmentDate(appointmentDate);
		Appointment.validateAppointmentDescription(appointmentDescription);
	}
 	
 	@Override
    public String toString() {
 		SimpleDateFormat sdf = new SimpleDateFormat("E MMM dd HH:mm:ss zzz yyyy"); 
 	    String formattedDate = sdf.format(appointmentDate);
        return "Appointment{" +
                "appointmentID='" + appointmentID + '\'' +
                ", appointmentDate='" + formattedDate + '\'' +
                ", appointmentDescription='" + appointmentDescription + '\'' +
                '}';
    }
}
