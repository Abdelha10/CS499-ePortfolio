/* author: Abdel Ouedraogo
 * Date: 08/11/2024
 * CS 320
 * Project One
 * program: AppointmentTest Class
 */

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;
import java.text.SimpleDateFormat;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

class AppointmentTest {

    // checks if the constructor sets the fields correctly and the getters return
    // the correct values
    @Test
    public void testConstructorAndGetters() {
        // Create an Appointment object with a specific date
        Date appointmentDate = new Date(System.currentTimeMillis() + 3600 * 1000);
        Appointment appt = new Appointment("00001234", appointmentDate, "Organize the list of customers");

        assertEquals("00001234", appt.getAppointmentID());
        // verify Compare Date objects correctly
        assertEquals(appointmentDate, appt.getAppointmentDate());
        assertEquals("Organize the list of customers", appt.getAppointmentDescription());
    }

    // checks if the setters update the fields correctly
    @Test
    public void testSetters() {
        // Create an Appointment object
        Date initialDate = new Date(System.currentTimeMillis() + 3600 * 1000);
        Appointment appt = new Appointment("123455432", initialDate, "Deploy the updates");

        // Update the appointment date and description
        Date newDate = new Date(System.currentTimeMillis() + 7200 * 1000);
        appt.setAppointmentDate(newDate);
        appt.setAppointmentDescription("Mentor new users");

        assertEquals("123455432", appt.getAppointmentID());
        assertEquals(newDate, appt.getAppointmentDate());
        assertEquals("Mentor new users", appt.getAppointmentDescription());
    }

    // checks if an IllegalArgumentException is thrown when the appointment ID is
    // invalid.
    @Test
    public void testInvalidAppointmentID() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                Date newDate = new Date(System.currentTimeMillis() + 7200 * 1000);
                new Appointment("00001111555A", newDate, "Message to customers");
            }
        });
        assertEquals("Appointment ID cannot be null and must be at most 10 characters.", thrown.getMessage());
    }

    // checks if an IllegalArgumentException is thrown when the description is
    // invalid.
    @Test
    public void testInvalidAppointmentDescription() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                Date newDate = new Date(System.currentTimeMillis() + 7200 * 1000);
                new Appointment("0000111155", newDate,
                        "Composing, sending email messages, and meeting customers is way to long");
            }
        });
        assertEquals("Appointment Description cannot be null and must be at most 50 characters.", thrown.getMessage());
    }

    // Test for null appointment date
    @Test
    public void testNullAppointmentDate() {
        try {
            new Appointment("0000111155", null, "Contact customers");
            fail("Expected IllegalArgumentException for null appointmentDate");
        } catch (IllegalArgumentException e) {
            assertEquals("Appointment Date cannot be null.", e.getMessage());
        }
    }

    // Test for past appointment date
    @Test
    public void testPastAppointmentDate() {
        // Create a date in the past (e.g., 1 hour ago)
        Date pastDate = new Date(System.currentTimeMillis() - 3600 * 1000);

        try {
            new Appointment("0000111155", pastDate, "Contact customers");
            fail("Expected IllegalArgumentException for past appointmentDate");
        } catch (IllegalArgumentException e) {
            assertEquals("Appointment Date cannot be in the past.", e.getMessage());
        }
    }

    // Test for valid appointment date
    @Test
    public void testValidAppointmentDate() {
        Date futureDate = new Date(System.currentTimeMillis() + 3600 * 1000); // 1 hour in the future
        Appointment appt = new Appointment("0000111155", futureDate, "Contact customers");

        // No exception should be thrown, so we can assert the values are set correctly
        assertEquals("0000111155", appt.getAppointmentID());
        assertEquals(futureDate, appt.getAppointmentDate());
        assertEquals("Contact customers", appt.getAppointmentDescription());
    }

    // checks if the toString method returns the correct string representation of
    // the Task object.
    @Test
    public void testToString() {
        Date aDate = new Date(System.currentTimeMillis() + 3600 * 1000);
        Appointment appt = new Appointment("0000111155", aDate, "Contact customers");

        // Format the date to match the expected output
        SimpleDateFormat sdf = new SimpleDateFormat("E MMM dd HH:mm:ss zzz yyyy");
        String formattedDate = sdf.format(aDate);
        String expected = "Appointment{appointmentID='0000111155', appointmentDate='" + formattedDate
                + "', appointmentDescription='Contact customers'}";
        assertEquals(expected, appt.toString());
    }

}
