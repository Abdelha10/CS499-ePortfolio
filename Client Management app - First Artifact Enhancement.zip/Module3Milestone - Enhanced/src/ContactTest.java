
/* author: Abdel Ouedraogo
 * Date: 8/11/2024
 * CS 320
 * Project One
 * program: ContactTest Class
 */
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import org.junit.jupiter.api.function.Executable;

public class ContactTest {

    // checks if the constructor sets the fields correctly and the getters return
    // the correct values
    @Test
    public void testConstructorAndGetters() {
        Contact contact = new Contact("123456789", "Ali", "Brown", "9563339090", "3455 Murray St");

        assertEquals("123456789", contact.getID());
        assertEquals("Ali", contact.getFirstName());
        assertEquals("Brown", contact.getLastName());
        assertEquals("9563339090", contact.getPhoneNumber());
        assertEquals("3455 Murray St", contact.getAddress());
    }

    // checks if the setters update the fields correctly
    @Test
    public void testSetters() {
        // Initialize with valid data first
        Contact contact = new Contact("123455432", "Init", "Init", "0000000000", "Init Address");
        contact.setFirstName("Ali");
        contact.setLastName("Brown");
        contact.setPhoneNumber("9563339090");
        contact.setAddress("3455 Murray St");

        assertEquals("123455432", contact.getID());
        assertEquals("Ali", contact.getFirstName());
        assertEquals("Brown", contact.getLastName());
        assertEquals("9563339090", contact.getPhoneNumber());
        assertEquals("3455 Murray St", contact.getAddress());
    }

    // checks if an IllegalArgumentException is thrown when the contactID is
    // invalid.
    @Test
    public void testInvalidContactID() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new Contact("09999778888", "Ali", "Brown", "9563339090", "3455 Murray St");
            }
        });
        assertEquals("Contact ID cannot be null and must be at most 10 characters.", thrown.getMessage());
    }

    // checks if an IllegalArgumentException is thrown when the firstName is
    // invalid.
    @Test
    public void testInvalidFirstName() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new Contact("123456789", "LongFirstNameThatExceedsLimit", "Brown", "9563339090", "3455 Murray St");
            }
        });
        assertEquals("First Name cannot be null and must be at most 10 characters.", thrown.getMessage());
    }

    // checks if an IllegalArgumentException is thrown when the lastName is invalid.
    @Test
    public void testInvalidLastName() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new Contact("123456789", "Ali", "LongLastNameThatExceedsLimit", "9563339090", "3455 Murray St");
            }
        });
        assertEquals("Last Name cannot be null and must be at most 10 characters.", thrown.getMessage());
    }

    // checks if an IllegalArgumentException is thrown when the phoneNumber is
    // invalid.
    @Test
    public void testInvalidPhoneNumber() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new Contact("123456789", "Ali", "Brown", "956", "3455 Murray St");
            }
        });
        assertEquals("Phone Number must be exactly 10 digits.", thrown.getMessage());

        // Test non-digit characters
        IllegalArgumentException thrown2 = assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123456789", "Ali", "Brown", "12345abcde", "3455 Murray St");
        });
        assertEquals("Phone Number must be exactly 10 digits.", thrown2.getMessage());
    }

    // checks if an IllegalArgumentException is thrown when the address is invalid.
    @Test
    public void testInvalidAddress() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new Contact("123456789", "Ali", "Brown", "9563339090",
                        "Someone that has a very long address exceeding the limit");
            }
        });
        assertEquals("Address cannot be null and must be at most 30 characters.", thrown.getMessage());
    }

    // checks if the toString method returns the correct string representation of
    // the Contact object.
    @Test
    public void testToString() {
        Contact contact = new Contact("123456789", "Ali", "Brown", "9563339090", "3455 Murray St");
        String expected = "Contact{contactID='123456789', firstName='Ali', lastName='Brown', phoneNumber='9563339090', address='3455 Murray St'}";
        assertEquals(expected, contact.toString());
    }
}