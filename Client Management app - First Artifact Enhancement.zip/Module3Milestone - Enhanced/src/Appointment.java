import java.text.SimpleDateFormat;
import java.util.Date;

public class Appointment {
	private final String appointmentID;
	private Date appointmentDate;
	private String appointmentDescription;

	public Appointment(String appointmentID, Date appointmentDate, String appointmentDescription) {
		this.appointmentID = appointmentID;
		this.appointmentDate = appointmentDate;
		this.appointmentDescription = appointmentDescription;
		validateAll();
	}

	// Create getter methods
	public String getAppointmentID() {
		return this.appointmentID;
	}

	public Date getAppointmentDate() {
		return this.appointmentDate;
	}

	public String getAppointmentDescription() {
		return this.appointmentDescription;
	}

	// Create setter methods
	public void setAppointmentDate(Date appointmentDate) {
		validateAppointmentDate(appointmentDate);
		this.appointmentDate = appointmentDate;
	}

	public void setAppointmentDescription(String appointmentDescription) {
		validateAppointmentDescription(appointmentDescription);
		this.appointmentDescription = appointmentDescription;
	}

	// Helper to validate all appointment information
	private void validateAll() {
		validateAppointmentID(appointmentID);
		validateAppointmentDate(appointmentDate);
		validateAppointmentDescription(appointmentDescription);
	}

	// Validation Helpers
	private void validateString(String value, int maxLength, String fieldName) {
		if (value == null || value.length() > maxLength) {
			throw new IllegalArgumentException(
					fieldName + " cannot be null and must be at most " + maxLength + " characters.");
		}
	}

	// validate task ID
	private void validateAppointmentID(String appointmentID) {
		validateString(appointmentID, 10, "Appointment ID");
	}

	// Validation method for appointment date
	private void validateAppointmentDate(Date appointmentDate) {
		if (appointmentDate == null) {
			throw new IllegalArgumentException("Appointment Date cannot be null.");
		}
		if (appointmentDate.before(new Date())) {
			throw new IllegalArgumentException("Appointment Date cannot be in the past.");
		}
	}

	// validate appointment description
	private void validateAppointmentDescription(String appointmentDescription) {
		validateString(appointmentDescription, 50, "Appointment Description");
	}

	@Override
	public String toString() {
		SimpleDateFormat sdf = new SimpleDateFormat("E MMM dd HH:mm:ss zzz yyyy");
		String formattedDate = sdf.format(appointmentDate);
		return "Appointment{" +
				"appointmentID='" + appointmentID + '\'' +
				", appointmentDate='" + formattedDate + '\'' +
				", appointmentDescription='" + appointmentDescription + '\'' +
				'}';
	}
}
