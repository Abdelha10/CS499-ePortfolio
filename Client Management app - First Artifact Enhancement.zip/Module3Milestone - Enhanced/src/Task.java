public class Task {

	private final String taskID;
	private String taskName;
	private String taskDescription;

	// Constructor
	public Task(String taskID, String taskName, String taskDescription) {
		this.taskID = taskID;
		this.taskName = taskName;
		this.taskDescription = taskDescription;
		validateAll();
	}

	// Create getter methods
	public String getTaskID() {
		return taskID;
	}

	public String getTaskName() {
		return taskName;
	}

	public String getTaskDescription() {
		return taskDescription;
	}

	// Create setter methods
	public void setTaskName(String taskName) {
		validateTaskName(taskName);
		this.taskName = taskName;
	}

	public void setTaskDescription(String taskDescription) {
		validateTaskDescription(taskDescription);
		this.taskDescription = taskDescription;
	}

	// Helper to validate all task information
	private void validateAll() {
		validateTaskID(taskID);
		validateTaskName(taskName);
		validateTaskDescription(taskDescription);
	}

	// Validation Helpers
	private void validateString(String value, int maxLength, String fieldName) {
		if (value == null || value.length() > maxLength) {
			throw new IllegalArgumentException(
					fieldName + " cannot be null and must be at most " + maxLength + " characters.");
		}
	}

	private void validateTaskID(String taskID) {
		validateString(taskID, 10, "Task ID");
	}

	private void validateTaskName(String taskName) {
		validateString(taskName, 20, "Task Name");
	}

	private void validateTaskDescription(String taskDescription) {
		validateString(taskDescription, 50, "Task Description");
	}

	@Override
	public String toString() {
		return "Task{" +
				"taskID='" + taskID + '\'' +
				", taskName='" + taskName + '\'' +
				", taskDescription='" + taskDescription + '\'' +
				'}';
	}
}
