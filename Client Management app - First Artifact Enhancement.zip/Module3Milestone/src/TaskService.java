import java.util.HashMap;
import java.util.Map;

public class TaskService {
	private Map<String, Task> tasks;
	
	public TaskService() {
		this.tasks = new HashMap<>();
	}
	
	//Add a task to the map
	public void addTask(Task task) {
		
		if (tasks.containsKey(task.getTaskID())) {
			 throw new IllegalArgumentException("Task ID must be unique: " + task.getTaskID());
		}
		
		tasks.put(task.getTaskID(), task);
		System.out.println("Task added successfully");
	}
	
	//Remove a task from the map
	public void removeTask(String taskID) {
		if(this.tasks.remove(taskID) != null) {
			System.out.println("Task deleted successfully: " + taskID);
		}
		else {
		    System.out.println("Task with ID " + taskID + " not found");
		}
	}
	
	//Update task name
	public boolean updateTaskName(String taskID, String newTaskName) {
	
		if(taskID == null || newTaskName == null) {
			throw new IllegalArgumentException("Invalid task ID or task name");
		}
		
		Task task = tasks.get(taskID);
		if (task == null) {
		    System.out.println("task with ID " + taskID + " not found");
		    return false;
		}
		   
		task.setTaskName(newTaskName);
		tasks.put(taskID, task);
		System.out.println("Task name updated successfully");
		return true;
	}
	
	//Update task description
	public boolean updateTaskDescription(String taskID, String newTaskDescription) {
		
		if(taskID == null || newTaskDescription == null) {
			throw new IllegalArgumentException("Invalid task ID or task Description");
		}
		
		Task task = tasks.get(taskID);
		if (task == null) {
		    System.out.println("task with ID " + taskID + " not found");
		    return false;
		}
		   
		task.setTaskDescription(newTaskDescription);
		tasks.put(taskID, task);
		System.out.println("Task description updated successfully");
		return true;
	}
	
	public Task getTask(String taskID)
	{
		return tasks.get(taskID);
	}
	
	public int getSize() {
		return tasks.size();
	}
	
}
