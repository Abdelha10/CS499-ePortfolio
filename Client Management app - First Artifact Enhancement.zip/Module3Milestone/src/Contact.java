
public class Contact {
	
	private final String contactID;
	private String firstName;
	private String lastName;
	private String phoneNumber;
	private String address;
	
	// Constructor to initialize contact ID
	public Contact(String contactID){
		this.contactID = contactID;
	}
		
	
	Contact(String contactID, String firstName, String lastName, String phoneNumber, String address) {
		
		this.contactID = contactID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNumber = phoneNumber;
		this.address = address;
		validateAll();
	
	}
	
	// Create getter methods
	public String getID() {
		return contactID;
	}
	
	public String getFirstName() {
		return firstName;

	}
	
	public String getLastName() {
		return lastName;
	}
	
	public String getPhoneNumber() {
		return phoneNumber;
	}
	
	public String getAddress() {
		return address;
	}
	
	// Create setter methods
	public void setFirstName(String firstName) {
		Contact.validateFirstName(firstName);
		this.firstName = firstName;
		
	}
	
	public void setLastName(String lastName) {
		Contact.validateLastName(lastName);
		this.lastName = lastName;
	}

	public void setPhoneNumber(String phoneNumber) {
		Contact.validatePhoneNumber(phoneNumber);
		this.phoneNumber = phoneNumber;
	}
	public void setAddress(String address) {
		Contact.validateAddress(address);
		this.address = address;
	}
	
	
	// Helper to validate contact information
	private void validateAll() {
		Contact.validateContactID(contactID);
		Contact.validateFirstName(firstName);
		Contact.validateLastName(lastName);
		Contact.validatePhoneNumber(phoneNumber);
		Contact.validateAddress(address);
	}
	
	//validate contact ID
	private static void validateContactID(String contactID) {
		if (contactID == null || contactID.length() > 10) {
			throw new IllegalArgumentException("Invalid ID");
		}
	}
	
	// validate contact first name
	static void validateFirstName(String firstName) {
		if (firstName == null || firstName.length() > 10) {
			throw new IllegalArgumentException("Invalid First Name");
		}
	}
	
	// validate contact last name
	private static void validateLastName(String lastName) {
		if (lastName == null || lastName.length() > 10) {
			throw new IllegalArgumentException("Invalid Last Name");
		}
	}
	
	// validate contact phone number
	private static void validatePhoneNumber(String phoneNumber) {
		if (phoneNumber == null || phoneNumber.length() != 10) {
			throw new IllegalArgumentException("Invalid Phone Number");
		}
	}
	
	// validate contact address
	private static void validateAddress(String address) {
		if (address == null || address.length() > 30) {
			throw new IllegalArgumentException("Invalid Address");
		}
	}
	
	@Override
    public String toString() {
        return "Contact{" +
                "contactID='" + contactID + '\'' +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", address='" + address + '\'' +
                '}';
    }
	
}
