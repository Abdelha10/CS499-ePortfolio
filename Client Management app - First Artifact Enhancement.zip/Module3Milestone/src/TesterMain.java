//import java.sql.Date;
import java.util.Date;

public class TesterMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Contact contact;
		// Initialize the object using the new keyword and constructor
		contact = new Contact("1234567890", "Bruce", "Rahman", "5551234567", "123 Main St");
		
		System.out.println(contact);
		
		ContactService contactService = new ContactService();
		
		contactService.addContacts(contact);
		contactService.updateFirstName("1234567890", "Abel");
		contactService.updateLastName("1234567890", "Dani");
		contactService.updateAddress("1234567890", "124 Cornelius Rd");
		contactService.updatePhoneNumber("1234567890", "4895637422");
		contactService.removeContact("1234567890");
		System.out.println(contact);
		
		//Task testing
		Task task;
		task = new Task("555", "Fix Phone", "Contact customer for follow up");
		
		System.out.println(task);
		TaskService taskService = new TaskService();
		taskService.addTask(task);
		taskService.updateTaskName("555", "Fix Com");
		taskService.updateTaskDescription("555", "Follow up call");
		taskService.removeTask("555");
		System.out.println(task);
		
		//appointment testing
		//Date apptDate = new Date(2024, 6, 10);
		
	    AppointmentService service = new AppointmentService();

	    // Create a valid appointment
	    Appointment appt1 = new Appointment("12345", new Date(System.currentTimeMillis() + 3600 * 1000), "Talks"); // 1 hour in the future
	    service.addAppointment(appt1);

	    // Retrieve the appointment
	    Appointment retrievedAppt = service.getAppointment("12345");
	    System.out.println(retrievedAppt);

	    // Attempt to add another appointment with the same ID (should throw an exception)
	    try {
	    	Appointment appt2 = new Appointment("12345", new Date(System.currentTimeMillis() + 7200 * 1000), "Get your opinion"); // 2 hours in the future
	        service.addAppointment(appt2);
	    } catch (IllegalArgumentException e) {
	            System.out.println(e.getMessage());
	    }

	    // Remove the appointment
	    service.removeAppointment("12345");

	    // Try to retrieve the removed appointment (should indicate not found)
	    service.getAppointment("12345");
		
	}

}
