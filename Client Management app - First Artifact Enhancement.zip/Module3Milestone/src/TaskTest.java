/* author: Abdel Ouedraogo
 * Date: 8/11/2024
 * CS 320
 * Project One
 * program: TaskTest Class
 */

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

class TaskTest {

	//checks if the constructor sets the fields correctly and the getters return the correct values
    @Test
    public void testConstructorAndGetters() {
        Task task = new Task("00001234", "Set up", "Organize the list of customers");

        assertEquals("00001234", task.getTaskID());
        assertEquals("Set up", task.getTaskName());
        assertEquals("Organize the list of customers", task.getTaskDescription());
    }

    //checks if the setters update the fields correctly
    @Test
    public void testSetters() {
        Task task = new Task("123455432");
        task.setTaskName("Mentoring");
        task.setTaskDescription("Mentor new users");

        assertEquals("123455432", task.getTaskID());
        assertEquals("Mentoring", task.getTaskName());
        assertEquals("Mentor new users", task.getTaskDescription());
    }

   //checks if an IllegalArgumentException is thrown when the task ID is invalid.
    @Test
    public void testInvalidTaskID() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new Task("00001111555T", "Send Email", "Composes and sends email messages to customers");
            }
        });
        assertEquals("Invalid task ID", thrown.getMessage());
    }

    //checks if an IllegalArgumentException is thrown when the task Name is invalid.
    @Test
    public void testInvalidTaskName() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new Task("0000111155", "Task name is way too      long ", "Composes and sends email messages to customers");
            }
        });
        assertEquals("Invalid task Name", thrown.getMessage());
    }

    //checks if an IllegalArgumentException is thrown when the description is invalid.
    @Test
    public void testInvalidTaskDescription() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new Task("0000111155", "Send Email", "Composing and sending email messages to customers is way to long");
            }
        });
        assertEquals("Invalid description", thrown.getMessage());
    }
    
   //checks if the toString method returns the correct string representation of the Task object.
    @Test
    public void testToString() {
        Task task = new Task("0000111155", "Send Email", "Composing and sending email messages to customers");
        String expected = "Task{taskID='0000111155', taskName='Send Email', taskDescription='Composing and sending email messages to customers'}";
        assertEquals(expected, task.toString());
    }
}
