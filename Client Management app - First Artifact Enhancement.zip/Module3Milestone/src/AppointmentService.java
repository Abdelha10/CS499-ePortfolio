import java.util.Map;
import java.util.HashMap;

public class AppointmentService {
	private Map<String, Appointment> appointments;
	
	public AppointmentService() {
		this.appointments = new HashMap<>();
	}
	
	//Add appointment with unique appointment ID
	public void addAppointment(Appointment appt) {
		if (appointments.containsKey(appt.getAppointmentID())) {
			 throw new IllegalArgumentException("Appointment ID must be unique: " + appt.getAppointmentID());
		}
		
		appointments.put(appt.getAppointmentID(), appt);
		System.out.println("Appointment added successfully");
	}
	
	//Remove appointment by ID
	public void removeAppointment(String apptID) {
		Appointment removedAppt = appointments.remove(apptID);
		if(removedAppt != null) {
			System.out.println("Appointment deleted successfully: " + apptID);
		}
		else {
		    System.out.println("Appointment with ID " + apptID + " not found");
		}
	
	}
	
	// Retrieve appointment by ID
	public Appointment getAppointment(String apptID) {
		Appointment appt = appointments.get(apptID);
		if (appt != null) {
			System.out.println("Appointment retrieved successfully: " + appt);
	    } else {
	    	System.out.println("Appointment with ID " + apptID + " not found");
	    }
	    return appt;
	}
	
	//Return the size of the map
	public int getSize() {
		return appointments.size();
	}
}
